document.addEventListener('DOMContentLoaded', () => {
  const board = document.getElementById('game-board');
  const resultScreen = document.getElementById('result-screen');
  const resultMessage = document.getElementById('result-message');
  const cells = [];

  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.addEventListener('click', () => handleClick(i));
    cells.push(cell);
    board.appendChild(cell);
  }

  let currentPlayer = 'X';
  let gameBoard = ['', '', '', '', '', '', '', '', ''];
  let gameActive = true;

  function handleClick(index) {
    if (gameBoard[index] === '' && gameActive) {
      gameBoard[index] = currentPlayer;
      cells[index].textContent = currentPlayer;
      if (checkWinner()) {
        showResultScreen(`Player ${currentPlayer} wins!`);
      } else if (isBoardFull()) {
        showResultScreen("It's a draw!");
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
      }
    }
  }

  function checkWinner() {
    const winningCombinations = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];

    for (const combo of winningCombinations) {
      const [a, b, c] = combo;
      if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
        highlightWinnerCells([a, b, c]);
        gameActive = false;
        return true;
      }
    }

    return false;
  }

  function isBoardFull() {
    return gameBoard.every(cell => cell !== '');
  }

  function highlightWinnerCells(cellsToHighlight) {
    cellsToHighlight.forEach(cellIndex => {
      cells[cellIndex].style.backgroundColor = '#8eff8e';
    });
  }

  function showResultScreen(message) {
    resultMessage.textContent = message;
    resultScreen.style.display = 'flex';
  }

  window.resetGame = function () {
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;

    // Clear the board
    cells.forEach(cell => {
      cell.textContent = '';
      cell.style.backgroundColor = '#fff';
    });

    // Hide the result screen
    resultScreen.style.display = 'none';
  };
});
